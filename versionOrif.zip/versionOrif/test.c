#include <stdio.h>

void	test(void)
{
	printf("ça marche aussi avec du code??");
}